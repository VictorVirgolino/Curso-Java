package com.jwtme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
