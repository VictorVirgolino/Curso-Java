package com.jwtme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtmeApplication.class, args);
	}

}
