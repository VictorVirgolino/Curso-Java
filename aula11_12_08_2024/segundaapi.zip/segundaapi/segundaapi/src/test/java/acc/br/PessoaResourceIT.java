package acc.br;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class PessoaResourceIT extends PessoaResourceTest {
    // Execute the same tests but in packaged mode.
}
