package com.accenture.pessoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaApplicationTests {

	@Test
	void contextLoads() {
	}

}
